# Waste Detection CNN, code and evidence package

This archive supports the CSCI 441/541 Research Assignment report. It contains the code I wrote, the exact generated config and metrics from the run discussed in the report, and the literature notes behind the research framing. It does not contain the TACO image dataset itself (1,500 images, several GB) since that is downloadable from its own source (see below) and not something I need to redistribute.

## Contents

```
scripts/                   all code
  download_taco.sh         downloads + extracts the official TACO v1.0 archive
  audit_dataset.py         computes real dataset statistics (counts, dimensions, class balance)
  prepare_dataset.py       builds the 18-class taxonomy, splits data 70/15/15, converts COCO -> YOLO labels
  test_coord_conversion.py correctness tests for the bbox conversion and split integrity
  train.py                 trains YOLO11n (E0 baseline / E1 augmented configs)
  evaluate.py               runs the final locked test-set evaluation
  predict.py                runs inference on external unseen images
configs/
  dataset.yaml              the generated Ultralytics dataset config this run actually used
docs/
  literature_notes.md       the 5-source literature scan referenced in the report
outputs/
  test_metrics.json          the real, logged test-set metrics reported in the report
experiments/
  E0_baseline/results.png    the training/validation curves shown in the report
  E0_baseline/weights/best.pt  the actual trained checkpoint used to produce every number in the report
```

## How to reproduce this run

1. Clone or recreate the repository structure (this archive assumes it sits at the root of that project; `scripts/` reference relative paths like `data/`, `configs/`, `experiments/` that exist in the full repo, not in this zip alone).
2. Create a virtual environment and install dependencies: `pip install ultralytics pillow numpy matplotlib tqdm`.
3. Download the dataset: `bash scripts/download_taco.sh` (pulls the official TACO v1.0 archive from Zenodo, DOI 10.5281/zenodo.3587843, CC-BY-4.0).
4. Audit it: `python scripts/audit_dataset.py` (writes `outputs/dataset_audit.json`).
5. Prepare it: `python scripts/prepare_dataset.py` (builds the taxonomy, split, and YOLO-format labels; writes `configs/dataset.yaml`, which is also included here already-generated from the actual run).
6. Verify the conversion: `python scripts/test_coord_conversion.py` (all tests should pass).
7. Train: `python scripts/train.py --exp E0 --epochs 50 --batch 16` (the checkpoint this produces should match `experiments/E0_baseline/weights/best.pt`, included here from the actual run, within normal run-to-run variance).
8. Evaluate: `python scripts/evaluate.py` (writes `outputs/test_metrics.json`, also included here already-generated).
9. Predict on new images: `python scripts/predict.py` (expects images in `data/unseen_external/`).

Full project, including all documentation of each phase's decisions and gates, is at: https://github.com/Yohanes-Mk/waste-detection-cnn
